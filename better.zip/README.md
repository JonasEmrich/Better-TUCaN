# Better TUCaN 

## What it does

This extension just includes:

* the content scripts, "script.js" and "style.css" that is injected into any pages
under "tucan.tu-darmstadt.de/" or any of its subdomains

The content scripts change the website appearance of "tucan.tu-darmstadt.de/" to a dark theme and add statistics to the gradeoverview.

## Credits
The Add-On Icon is made by freepik.com from flaticon.com
The original "TUCaN" Logo and the Logo of "Technische University Darmstadt" belongs and is property of the Technische University Darmstadt